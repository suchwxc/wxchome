#pragma once
#ifdef USE_ESP32

namespace esphome {
namespace esp32 {

void setup_preferences();

}  // namespace esp32
}  // namespace esphome

#endif  // USE_ESP32
